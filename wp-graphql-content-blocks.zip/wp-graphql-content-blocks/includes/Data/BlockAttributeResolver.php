<?php
/**
 * Used to resolve attributes from a block Model.
 *
 * @package WPGraphQL\ContentBlocks\Data
 */

namespace WPGraphQL\ContentBlocks\Data;

use WPGraphQL\ContentBlocks\Utilities\DOMHelpers;

/**
 * Class BlockAttributeResolver
 */
final class BlockAttributeResolver {
	/**
	 * Resolve the value of a single block attribute based on the specified config.
	 *
	 * @internal This method should only be used internally. There are no guarantees for backwards compatibility.
	 *
	 * @param array<string,mixed>  $attribute The configuration for the specific attribute.
	 * @param string               $html The block rendered html.
	 * @param mixed                $attribute_value The value from the parsed block attributes.
	 * @param ?array<string,mixed> $attribute_values All parsed block attributes, used by the `attrs` source.
	 *
	 * @return mixed
	 */
	public static function resolve_block_attribute( $attribute, string $html, $attribute_value, ?array $attribute_values = null ) {

		$source = $attribute['source'] ?? null;
		// Return at the earliest point to reduce overhead
		if ( ! $source ) {
			return self::get_default_attribute_value( $attribute, $attribute_value );
		}

		$value = null;

		// @todo parse remaining sources: https://github.com/WordPress/gutenberg/blob/trunk/packages/blocks/src/api/parser/get-block-attributes.js#L198
		switch ( $source ) {
			case 'attribute':
				$value = self::parse_attribute_source( $html, $attribute );
				break;
			case 'html':
			case 'rich-text':
				// If there is no selector, the source is the node's innerHTML.
				if ( ! isset( $attribute['selector'] ) ) {
					$value = ! empty( $html ) ? DOMHelpers::find_nodes( $html )->innerHTML() : null;
					break;
				}
				$value = self::parse_html_source( $html, $attribute );
				break;
			case 'text':
				$value = self::parse_text_source( $html, $attribute );
				break;
			case 'query':
				$value = self::parse_query_source( $html, $attribute, $attribute_value );
				break;
			case 'tag':
				$value = self::parse_tag_source( $html );
				break;
			case 'meta':
				$value = self::parse_meta_source( $attribute );
				break;
			case 'attrs':
				$value = self::parse_attrs_source( $attribute_values, $attribute );
				break;
		}

		$type = $attribute['type'] ?? null;
		if ( ! $type ) {
			return ( null === $value )
				? self::get_default_attribute_value( $attribute, $attribute_value )
				: $value;
		}

		switch ( $type ) {
			case 'integer':
				$value = intval( $value );
				break;
			case 'boolean':
				// Boolean attributes can be an empty string.
				$value = ( ! is_array( $value ) && isset( $value ) ) || ! empty( $value );
				break;
		}

		return ( null === $value )
			? self::get_default_attribute_value( $attribute, $attribute_value )
			: $value;
	}

	/**
	 * Parses the block content of an HTML source block type.
	 *
	 * Includes `multiline` handling.
	 *
	 * @param string              $html The html value.
	 * @param array<string,mixed> $config The value configuration.
	 */
	private static function parse_html_source( string $html, array $config ): ?string {
		if ( empty( $html ) || ! isset( $config['selector'] ) ) {
			return null;
		}

		$result = DOMHelpers::parse_html( $html, $config['selector'] );

		// Multiline values are located somewhere else.
		if ( isset( $config['multiline'] ) && ! empty( $result ) ) {
			$result = DOMHelpers::get_elements_from_html( $result, $config['multiline'] );
		}

		return $result;
	}

	/**
	 * Parses an attribute source block type.
	 *
	 * @param string              $html The html value.
	 * @param array<string,mixed> $config The value configuration.
	 */
	private static function parse_attribute_source( string $html, array $config ): ?string {
		if ( empty( $html ) || ! isset( $config['attribute'] ) ) {
			return null;
		}

		return DOMHelpers::parse_attribute( $html, $config['selector'] ?? '', $config['attribute'] );
	}

	/**
	 * Parses a text source block type.
	 *
	 * @param string              $html The html value.
	 * @param array<string,mixed> $config The value configuration.
	 */
	private static function parse_text_source( string $html, $config ): ?string {
		if ( ! isset( $config['selector'] ) ) {
			return null;
		}

		return DOMHelpers::parse_text( $html, $config['selector'] );
	}

	/**
	 * Parses a query source block type.
	 *
	 * @param string               $html The html value.
	 * @param array<string,mixed>  $config The value configuration.
	 * @param ?array<string,mixed> $attribute_values The attribute values for the block.
	 *
	 * @return ?mixed[]
	 */
	private static function parse_query_source( string $html, array $config, ?array $attribute_values ): ?array {
		if ( ! isset( $config['selector'] ) || ! isset( $config['query'] ) ) {
			return null;
		}

		$nodes = DOMHelpers::find_nodes( $html, $config['selector'] );

		// Coerce nodes to an array if it's not already.
		if ( ! is_array( $nodes ) ) {
			$nodes = [ $nodes ];
		}

		$results = [];
		foreach ( $nodes as $source_node ) {
			// Holds the results for each query.
			$temp = [];

			foreach ( $config['query'] as $q_key => $q_value ) {
				$attribute_value = $attribute_values[ $q_key ] ?? null;

				$res = self::resolve_block_attribute( $q_value, $source_node->html(), $attribute_value, $attribute_values );

				$temp[ $q_key ] = $res;
			}

			$results[] = $temp;
		}

		return $results;
	}

	/**
	 * Parses a meta source block type.
	 *
	 * Note: Meta sources are considered deprecated but may still be used by legacy and third-party blocks.
	 *
	 * @see https://github.com/WordPress/gutenberg/blob/trunk/docs/reference-guides/block-api/block-attributes.md#meta-source-deprecated
	 *
	 * @param array<string,mixed> $config The attribute configuration.
	 */
	private static function parse_meta_source( array $config ): ?string {
		global $post_id;

		if ( empty( $post_id ) || empty( $config['meta'] ) ) {
			return null;
		}

		return get_post_meta( $post_id, $config['meta'], true );
	}

	/**
	 * Parses a tag source.
	 *
	 * @param string $html The html value.
	 */
	private static function parse_tag_source( string $html ): ?string {
		return DOMHelpers::get_first_node_tag_name( $html );
	}

	/**
	 * Parses a nested path out of the parsed block attributes.
	 *
	 * Used for values that block supports serialize into the generic `style`
	 * object rather than a top-level attribute, such as
	 * `style.typography.textAlign`.
	 *
	 * @param ?array<string,mixed> $attribute_values All parsed block attributes.
	 * @param array<string,mixed>  $config The value configuration.
	 *
	 * @return mixed
	 */
	private static function parse_attrs_source( ?array $attribute_values, array $config ) {
		if ( null === $attribute_values || empty( $config['path'] ) || ! is_array( $config['path'] ) ) {
			return null;
		}

		$value = $attribute_values;

		foreach ( $config['path'] as $segment ) {
			if ( ! is_array( $value ) || ! array_key_exists( $segment, $value ) ) {
				return null;
			}

			$value = $value[ $segment ];
		}

		return $value;
	}

	/**
	 * Get fallback value which is either attributes or default value
	 *
	 * @param array<string,mixed> $attribute The configuration for the specific attribute.
	 * @param mixed               $attribute_value The value from the parsed block attributes.
	 *
	 * @return mixed
	 */
	public static function get_default_attribute_value( $attribute, $attribute_value ) {
		$default = $attribute['default'] ?? null;

		return $attribute_value ?? $default;
	}
}
